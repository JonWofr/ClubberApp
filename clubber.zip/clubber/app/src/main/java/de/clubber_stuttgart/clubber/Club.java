package de.clubber_stuttgart.clubber;

public class Club {
    int id;
    String name;
    String adrs;
    String tel;
    String web;

   public Club (int id, String name, String adrs, String tel, String web){
        this.id = id;
        this.name = name;
        this.adrs = adrs;
        this.tel = tel;
        this.web = web;
    }
}

