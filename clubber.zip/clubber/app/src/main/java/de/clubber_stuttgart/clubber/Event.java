package de.clubber_stuttgart.clubber;


public class Event {

    int id;
    String dte;
    String name;
    String club;
    String srttime;
    String btn;
    String genre;

   public Event (int id, String dte, String name, String club, String srttime, String btn, String genre){
        this.id = id;
        this.dte = dte;
        this.name = name;
        this.club = club;
        this.srttime = srttime;
        this.btn = btn;
        this.genre = genre;
   }
}


